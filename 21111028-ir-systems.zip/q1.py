
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer, PorterStemmer
from nltk.tokenize import sent_tokenize , word_tokenize
import glob
import re
import os
import numpy as np
import sys
import math
from pathlib import Path
from collections import Counter
import numpy as nap
Stopwords = set(stopwords.words('english'))
ps=PorterStemmer()
import pickle

corpora = 'english-corpora/*'
ps = PorterStemmer()

doc_words=[]  
doc_word_count=[] 
dict_global = {} 
word_count_in_doc={} 
files_with_index = {} 
i=0
idx = 0
for file in glob.glob(corpora):
    i=i+1
    fname = file
    file = open(file , "r",encoding='UTF-8')
    text = file.read()
    text = re.sub('[^a-zA-Z\s]','',text)
    tokens = word_tokenize(text)
    word_count_in_doc[idx] = len(tokens)
    words=[]
    for word in tokens:
        if len(word)>1:
            word=ps.stem(word)
            if word not in Stopwords:
                words.append(word)
    doc_words.append(words)
    counter = dict(Counter(words))
    dict_global.update(counter)
    doc_word_count.append(counter)
    files_with_index[idx] = os.path.basename(fname)
    idx = idx + 1
    
unique_words_all = set(dict_global.keys())

tf = {x: {} for x in unique_words_all}
df = {x:0 for x in unique_words_all}

idx =0
for doc in doc_word_count:
    for i in doc.keys():
        df[i]=df[i]+1
        tf[i][idx]=doc[i]   
    idx=idx+1 
print("Finished")

Ltot = sum(word_count_in_doc.values())
Ltot

doc_norm={}
idx=0
files_count = len(files_with_index)
for i in doc_word_count:  # i is per doc  dicitonary
    l2=0
    for j in i.keys():
        l2+=(i[j]*math.log(files_count/df[j]))**2
    doc_norm[idx]=(math.sqrt(l2))
    idx +=1
    print(idx)

doc_norm

a_file = open("file_idx.pkl", "wb")
pickle.dump(files_with_index, a_file)
a_file.close()
a_file = open("unique_words_all.pkl", "wb")
pickle.dump(unique_words_all , a_file)
a_file.close()

import pickle
with open('posting_list.pkl','wb') as file:
    pickle.dump(tf,file)
    file.close()
with open('tf.pkl','wb') as file:
    pickle.dump(tf,file)
    file.close()

with open('df.pkl','wb') as file:
    pickle.dump(df,file)
    file.close()
    
with open('doc_len.pkl','wb') as file:
    pickle.dump(word_count_in_doc,file)
    file.close()
    
with open('doc_words.pkl','wb') as file:
    pickle.dump(doc_words,file)
    file.close()
    
with open('doc_norm.pkl','wb') as file:
    pickle.dump(doc_norm,file)
    file.close()

with open('file_idx.pkl','wb') as file:
    pickle.dump(files_with_index,file)
    file.close()



