
#importing all the libraries
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer, PorterStemmer
from nltk.tokenize import sent_tokenize , word_tokenize
import glob
import re
import os
import numpy as np
import sys
import math
from pathlib import Path
from collections import Counter
import numpy as np
Stopwords = set(stopwords.words('english'))
ps=PorterStemmer()
import pickle
import pandas as pd
import sys

# removing special characters
def remove_special_characters(text):
        pattern = re.compile('[^a-zA-Z\s]')
        cleaned_text = re.sub(pattern,' ',text)
        return cleaned_text

#boolean retrieval system

def boolean(query, counter=10):
    temp=open('picklefiles/posting_list.pkl',"rb")
    posting_lists=pickle.load(temp)

    temp=open('picklefiles/file_idx.pkl','rb')
    file_index=pickle.load(temp)
        
    unique_words=set(posting_lists.keys())
 
    # clean the query
    query = remove_special_characters(query)
    query = word_tokenize(query)

    words=[]
    for word in query:
        if len(word)>1:
            word=ps.stem(word)
            if word not in Stopwords:
                words.append(word)

    n=len(file_index)
    word_vector=[]
    word_vector_matrix=[]

    for w in words:
        word_vector=[0]*n
        if w in unique_words:
            for x in posting_lists[w].keys():
                word_vector[x]=1
        word_vector_matrix.append(word_vector)

    len_words = len(words)
    len_words = len_words - 1

    for i in range(len_words):

        vector1=word_vector_matrix[0]
        vector2=word_vector_matrix[1]

        result=[b1&b2 for b1,b2 in zip(vector1,vector2)]
            
        word_vector_matrix.pop(0)
        word_vector_matrix.pop(0)
            
        word_vector_matrix.insert(0,result)

    final_word_vector = word_vector_matrix[0]
    count=0
    files=[]
    for i in final_word_vector:
        if i==1:
            files.append(file_index[count])
        count+=1
    return files[:10]


#TF_IDF system

def tfidf(query):

    with open('picklefiles/df.pkl','rb') as file:
        DF=pickle.load(file)
        file.close()

    with open('picklefiles/posting_list.pkl','rb') as file:
        tf=pickle.load(file)
        file.close()
        
    with open('picklefiles/file_idx.pkl','rb') as file:
        file_idx=pickle.load(file)
        file.close()
        
    with open('picklefiles/doc_words.pkl','rb') as file:
        doc_words=pickle.load(file)
        file.close()

    with open('picklefiles/doc_norm.pkl','rb') as file:
        doc_norm=pickle.load(file)
        file.close()


    text = remove_special_characters(query)
    text = re.sub(re.compile('\d'),'',text)
    words = word_tokenize(text)
    words = [word.lower() for word in words]
    words=[ps.stem(word) for word in words]
    words=[word for word in words if word not in Stopwords]
    words=[word for word in words if word in tf.keys()]

    q=[]
    query_norm=0
    for w in words:
        tf_idf=(words.count(w)*math.log(len(file_idx)/DF[w]))
        q.append(tf_idf)
        query_norm+=tf_idf**2
    query_norm=math.sqrt(query_norm)

    q=np.array(q)/query_norm    #query words normalization


    score={}

    for i in range(len(file_idx)):
        doc_v=[]
        for w in words:
            tf_idf=(doc_words[i].count(w)*math.log(len(file_idx)/DF[w]))
            doc_v.append(tf_idf)

        doc_v=np.array(doc_v)
        score[i]=np.dot(q,doc_v)/doc_norm[i]

    score=sorted(score.items(),key=lambda x:x[1],reverse=True)


    result = []
    count = 10
    for i in score:
        if count == 0:
            break
        result.append([file_idx[i[0]], i[1]])
        #print(file_idx[i[0]],i[1])
        count-=1
    
    return result


#BM-25 IR system

def bm25(query):

    with open('picklefiles/posting_list.pkl','rb') as file:
        tf=pickle.load(file)
        file.close()
        
    with open('picklefiles/df.pkl','rb') as file:
        DF=pickle.load(file)
        file.close()
        
    with open('picklefiles/file_idx.pkl','rb') as file:
        file_idx=pickle.load(file)
        file.close()
        
    with open('picklefiles/doc_len.pkl','rb') as file:
        doc_len=pickle.load(file)
        file.close()

    k=0
    len_doc=doc_len
    N=len(file_idx)
    for i in len_doc:
        k+=len_doc[i]
    average_length=k/N
    average_length


    def IDF(word):
        average_length=0
        if word in DF:
            average_length=DF[word]
        ans=math.log((N-average_length+0.5)/(average_length+0.5))
        return ans

    def score_doc(text):
        text = remove_special_characters(text)
        text = re.sub(re.compile('\d'),'',text)
        words = word_tokenize(text)
        words = [word.lower() for word in words]
        words=[ps.stem(word) for word in words]
        words=[word for word in words if word not in Stopwords]
        for i in range(len(file_idx)):
            score[i]=0
            for ww in words:
                TF=0
                if ww in tf:
                    if i in tf[ww]:
                        TF=tf[ww][i]
                idf=IDF(ww)
                ans=idf*(k+1)*TF/(TF+k*(1-b+b*(len_doc[i]/average_length)))
                score[i]+=ans
                

    k=1.2
    b=0.75

    score={}
    for i in range(len(file_idx)):
        score[i]=0
    score_doc(query)
    score=sorted(score.items(),key=lambda item: item[1],reverse=True)


    result = []
    count = 10
    for i in score:
        if count == 0:
            break

        result.append([file_idx[i[0]],i[1]])
        count-=1
    
    return result

# reading the query input files here 
query_list=pd.read_csv('query.txt',sep='\t',header=None)
query_list.columns=['qid','query']


with open('picklefiles/file_idx.pkl',"rb") as temp:
    file_idx=pickle.load(temp)
    temp.close()


csv=[]
for index, row in query_list.iterrows():
    files=boolean(row['query'])
    for file in files:
        csv.append([row['qid'],1,file,1])
    if len(files)<5:
        remaining=[i for i in file_idx.values() if i not in files]
        remaining=remaining[:5-len(files)]
        for file in remaining:
            csv.append([row['qid'],1,file,0])
pd.DataFrame(csv,columns=['QueryID','Iteration','DocId','Relevance']).to_csv('Output/BRS.csv',index=False)
print("Boolean system done")



csv=[]
for index, row in query_list.iterrows():
    files=tfidf(row['query'])
    for file in files:
        relevance=0
        if file[1]>0:
            relevance=1
        csv.append([row['qid'],1,file[0],relevance])
pd.DataFrame(csv,columns=['QueryID','Iteration','DocId','Relevance']).to_csv('Output/TFIDF.csv',index=False)
print("TF-IDF done")

csv=[]
for index, r in query_list.iterrows():
    files=bm25(r['query'])
    for file in files:
        relevance=0
        if file[1]>0:
            relevance=1
        csv.append([r['qid'],1,file[0],relevance])



pd.DataFrame(csv,columns=['QueryID','Iteration','DocId','Relevance']).to_csv('Output/BM25.csv',index=False)
print("BM25 done")
print("Finished--- Qrels generated for given queries in output folder")
